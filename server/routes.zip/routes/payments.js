const express = require("express")
const router = express.Router()
const Payment = require("../models/Payment")
const Enrollment = require("../models/Enrollment")
const Course = require("../models/Course")
const User = require("../models/User")
const PromoCode = require("../models/PromoCode")
const auth = require("../middleware/auth")
require("dotenv").config(); // Ensure environment variables are loaded
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("❌ STRIPE_SECRET_KEY not set in .env file");
}
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

// Create Stripe checkout session
router.post("/create-session", auth, async (req, res) => {
  try {
    const { courseId, amount, promoCode, billingInfo, paymentMethod } = req.body
    const userId = req.user.id

    // Fetch course details
    const course = await Course.findById(courseId)
    if (!course) {
      return res.status(404).json({ message: "Course not found" })
    }

    // Check if user is already enrolled
    const existingEnrollment = await Enrollment.findOne({
      user: userId,
      course: courseId,
    })

    if (existingEnrollment) {
      return res.status(400).json({ message: "Already enrolled in this course" })
    }

    // Validate promo code if provided
    let discount = 0
    let validPromoCode = null
    if (promoCode) {
      validPromoCode = await PromoCode.findOne({
        code: promoCode.toUpperCase(),
        isActive: true,
        validFrom: { $lte: new Date() },
        validUntil: { $gte: new Date() },
        $or: [{ isGlobal: true }, { applicableCourses: courseId }],
      })

      if (!validPromoCode) {
        return res.status(400).json({ message: "Invalid or expired promo code" })
      }

      if (validPromoCode.usageLimit && validPromoCode.usedCount >= validPromoCode.usageLimit) {
        return res.status(400).json({ message: "Promo code usage limit exceeded" })
      }

      // Calculate discount
      if (validPromoCode.discountType === "percentage") {
        discount = (course.price * validPromoCode.discountValue) / 100
      } else {
        discount = validPromoCode.discountValue
      }
    }

    const finalAmount = Math.max(0, (amount || course.price) - discount)

    // Create payment record
    const payment = new Payment({
      user: userId,
      course: courseId,
      amount: finalAmount,
      promoCode: validPromoCode?.code,
      discount: discount,
      billingInfo,
      paymentMethod,
      status: "pending",
    })

    // Create Stripe checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: course.title,
              description: course.description,
              images: course.thumbnail ? [course.thumbnail] : [],
            },
            unit_amount: Math.round(finalAmount * 100), // Convert to cents
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${process.env.FRONTEND_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/payment/failed?course_id=${courseId}`,
      metadata: {
        courseId: courseId,
        userId: userId,
        paymentId: payment._id.toString(),
        promoCode: validPromoCode?.code || "",
      },
      customer_email: billingInfo.email,
      billing_address_collection: "required",
    })

    // Update payment with session ID
    payment.stripeSessionId = session.id
    await payment.save()

    res.json({
      sessionId: session.id,
      paymentId: payment._id,
    })
  } catch (error) {
    console.error("Payment session creation error:", error)
    res.status(500).json({ message: "Failed to create payment session" })
  }
})

// Verify payment and create enrollment
router.post("/verify", auth, async (req, res) => {
  try {
    const { sessionId } = req.body
    const userId = req.user.id

    // Retrieve the session from Stripe
    const session = await stripe.checkout.sessions.retrieve(sessionId)

    if (session.payment_status !== "paid") {
      return res.status(400).json({ message: "Payment not completed" })
    }

    // Find the payment record
    const payment = await Payment.findOne({
      stripeSessionId: sessionId,
      user: userId,
    }).populate("course")

    if (!payment) {
      return res.status(404).json({ message: "Payment record not found" })
    }

    if (payment.status === "completed") {
      // Already processed
      const enrollment = await Enrollment.findOne({
        user: userId,
        course: payment.course._id,
      })

      return res.json({
        status: "success",
        payment: payment,
        course: payment.course,
        enrollment: enrollment,
      })
    }

    // Update payment status
    payment.status = "completed"
    payment.stripePaymentIntentId = session.payment_intent
    payment.completedAt = new Date()
    await payment.save()

    // Create enrollment
    const enrollment = new Enrollment({
      user: userId,
      course: payment.course._id,
      payment: payment._id,
      progress: {
        totalLessons: 10, // This should be calculated based on actual course content
        completionPercentage: 0,
        lastAccessedAt: new Date(),
      },
    })

    await enrollment.save()

    // Update course enrollment count
    await Course.findByIdAndUpdate(payment.course._id, {
      $inc: { enrollmentCount: 1 },
    })

    // Update promo code usage if applicable
    if (payment.promoCode) {
      await PromoCode.findOneAndUpdate({ code: payment.promoCode }, { $inc: { usedCount: 1 } })
    }

    // Update user's last login
    await User.findByIdAndUpdate(userId, {
      lastLoginAt: new Date(),
    })

    res.json({
      status: "success",
      payment: payment,
      course: payment.course,
      enrollment: enrollment,
    })
  } catch (error) {
    console.error("Payment verification error:", error)
    res.status(500).json({ message: "Failed to verify payment" })
  }
})

// Validate promo code
router.post("/validate-promo", auth, async (req, res) => {
  try {
    const { code, courseId } = req.body

    const promoCode = await PromoCode.findOne({
      code: code.toUpperCase(),
      isActive: true,
      validFrom: { $lte: new Date() },
      validUntil: { $gte: new Date() },
      $or: [{ isGlobal: true }, { applicableCourses: courseId }],
    })

    if (!promoCode) {
      return res.status(400).json({ message: "Invalid or expired promo code" })
    }

    if (promoCode.usageLimit && promoCode.usedCount >= promoCode.usageLimit) {
      return res.status(400).json({ message: "Promo code usage limit exceeded" })
    }

    res.json({
      code: promoCode.code,
      discount: promoCode.discountValue,
      discountType: promoCode.discountType,
      description: promoCode.description,
    })
  } catch (error) {
    console.error("Promo code validation error:", error)
    res.status(500).json({ message: "Failed to validate promo code" })
  }
})

// Get payment history
router.get("/history", auth, async (req, res) => {
  try {
    const userId = req.user.id

    const payments = await Payment.find({ user: userId })
      .populate("course", "title instructor thumbnail")
      .sort({ createdAt: -1 })

    res.json(payments)
  } catch (error) {
    console.error("Payment history error:", error)
    res.status(500).json({ message: "Failed to fetch payment history" })
  }
})

// Request refund
router.post("/refund", auth, async (req, res) => {
  try {
    const { paymentId, reason } = req.body
    const userId = req.user.id

    const payment = await Payment.findOne({
      _id: paymentId,
      user: userId,
      status: "completed",
    })

    if (!payment) {
      return res.status(404).json({ message: "Payment not found or not eligible for refund" })
    }

    // Check if refund is within 30 days
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    if (payment.completedAt < thirtyDaysAgo) {
      return res.status(400).json({ message: "Refund period has expired (30 days)" })
    }

    // Create refund in Stripe
    const refund = await stripe.refunds.create({
      payment_intent: payment.stripePaymentIntentId,
      reason: "requested_by_customer",
    })

    // Update payment record
    payment.status = "refunded"
    payment.refundId = refund.id
    payment.refundReason = reason
    await payment.save()

    // Remove enrollment
    await Enrollment.findOneAndDelete({
      user: userId,
      course: payment.course,
    })

    // Update course enrollment count
    await Course.findByIdAndUpdate(payment.course, {
      $inc: { enrollmentCount: -1 },
    })

    res.json({
      message: "Refund processed successfully",
      refundId: refund.id,
    })
  } catch (error) {
    console.error("Refund error:", error)
    res.status(500).json({ message: "Failed to process refund" })
  }
})

// Stripe webhook handler
router.post("/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  const sig = req.headers["stripe-signature"]
  let event

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET)
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message)
    return res.status(400).send(`Webhook Error: ${err.message}`)
  }

  // Handle the event
  switch (event.type) {
    case "checkout.session.completed":
      const session = event.data.object
      await handleSuccessfulPayment(session)
      break

    case "payment_intent.payment_failed":
      const failedPayment = event.data.object
      await handleFailedPayment(failedPayment)
      break

    default:
      console.log(`Unhandled event type ${event.type}`)
  }

  res.json({ received: true })
})

// Helper function to handle successful payment
async function handleSuccessfulPayment(session) {
  try {
    const { courseId, userId, paymentId } = session.metadata

    const payment = await Payment.findById(paymentId)
    if (!payment || payment.status === "completed") {
      return // Already processed
    }

    // Update payment status
    payment.status = "completed"
    payment.stripePaymentIntentId = session.payment_intent
    payment.completedAt = new Date()
    await payment.save()

    // Create enrollment if not exists
    const existingEnrollment = await Enrollment.findOne({
      user: userId,
      course: courseId,
    })

    if (!existingEnrollment) {
      const enrollment = new Enrollment({
        user: userId,
        course: courseId,
        payment: paymentId,
        progress: {
          totalLessons: 10,
          completionPercentage: 0,
          lastAccessedAt: new Date(),
        },
      })

      await enrollment.save()

      // Update course enrollment count
      await Course.findByIdAndUpdate(courseId, {
        $inc: { enrollmentCount: 1 },
      })

      // Update promo code usage if applicable
      if (payment.promoCode) {
        await PromoCode.findOneAndUpdate({ code: payment.promoCode }, { $inc: { usedCount: 1 } })
      }
    }
  } catch (error) {
    console.error("Error handling successful payment:", error)
  }
}

// Helper function to handle failed payment
async function handleFailedPayment(paymentIntent) {
  try {
    const payment = await Payment.findOne({
      stripePaymentIntentId: paymentIntent.id,
    })

    if (payment) {
      payment.status = "failed"
      await payment.save()
    }
  } catch (error) {
    console.error("Error handling failed payment:", error)
  }
}

// Get error details for failed payments
router.get("/error-details/:sessionId", async (req, res) => {
  try {
    const { sessionId } = req.params

    const session = await stripe.checkout.sessions.retrieve(sessionId)

    if (session.payment_intent) {
      const paymentIntent = await stripe.paymentIntents.retrieve(session.payment_intent)

      res.json({
        code: paymentIntent.last_payment_error?.code || "unknown_error",
        message: paymentIntent.last_payment_error?.message || "Payment failed",
        transactionId: session.id,
        timestamp: new Date(session.created * 1000),
      })
    } else {
      res.json({
        code: "session_error",
        message: "Payment session error",
        transactionId: session.id,
        timestamp: new Date(session.created * 1000),
      })
    }
  } catch (error) {
    console.error("Error fetching error details:", error)
    res.status(500).json({ message: "Failed to fetch error details" })
  }
})

module.exports = router
