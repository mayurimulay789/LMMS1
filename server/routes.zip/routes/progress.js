// import express from "express"
// import Enrollment from "../models/Enrollment.js"
// import { authenticate } from "../middleware/auth.js"
// import { generateCertificate } from "../utils/certificateGenerators.js"

// const router = express.Router()

// // Update lesson progress
// router.post("/update", authenticate, async (req, res) => {
//   try {
//     const { courseId, moduleId, lessonId, completed, watchTime } = req.body

//     const enrollment = await Enrollment.findOne({
//       user: req.user._id,
//       course: courseId,
//     })

//     if (!enrollment) {
//       return res.status(404).json({ message: "Enrollment not found" })
//     }

//     // Find and update progress
//     const progressItem = enrollment.progress.find(
//       (p) => p.moduleId.toString() === moduleId && p.lessonId.toString() === lessonId,
//     )

//     if (!progressItem) {
//       return res.status(404).json({ message: "Progress item not found" })
//     }

//     progressItem.completed = completed
//     progressItem.watchTime = watchTime || progressItem.watchTime

//     if (completed && !progressItem.completedAt) {
//       progressItem.completedAt = new Date()
//     }

//     // Recalculate overall progress
//     enrollment.calculateProgress()
//     enrollment.lastAccessedAt = new Date()

//     await enrollment.save()

//     // Check if course is completed and generate certificate
//     if (enrollment.overallProgress === 100 && !enrollment.certificateIssued) {
//       try {
//         await generateCertificate(enrollment._id)
//         enrollment.certificateIssued = true
//         await enrollment.save()
//       } catch (certError) {
//         console.error("Certificate generation failed:", certError)
//       }
//     }

//     res.json({
//       message: "Progress updated successfully",
//       progress: enrollment.overallProgress,
//     })
//   } catch (error) {
//     res.status(500).json({ message: "Server error", error: error.message })
//   }
// })

// // Get course progress
// router.get("/:courseId", authenticate, async (req, res) => {
//   try {
//     const enrollment = await Enrollment.findOne({
//       user: req.user._id,
//       course: req.params.courseId,
//     }).populate("course", "title modules")

//     if (!enrollment) {
//       return res.status(404).json({ message: "Enrollment not found" })
//     }

//     res.json({
//       progress: enrollment.progress,
//       overallProgress: enrollment.overallProgress,
//       completedAt: enrollment.completedAt,
//       certificateIssued: enrollment.certificateIssued,
//     })
//   } catch (error) {
//     res.status(500).json({ message: "Server error", error: error.message })
//   }
// })

// export default router
