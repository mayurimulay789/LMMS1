"use client"

import AdminUserManagement from "../Components/AdminUserManagement"

const AdminUsersPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <AdminUserManagement />
    </div>
  )
}

export default AdminUsersPage
